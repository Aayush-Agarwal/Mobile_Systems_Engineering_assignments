//
//  RSViewController.m
//  loginfinal
//
//  Created by MSE on 21/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import "RSViewController.h"
#import "newpage.h"


@implementation RSViewController
@synthesize textone;
@synthesize texttwo;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)whenC:(id)sender {
   NSString *uname=@"somil";
   NSString *upass=@"qwerty";
   if(([uname isEqualToString:textone.text])&&([upass isEqualToString:texttwo.text]))
   {
       UIAlertView *cor=[[UIAlertView alloc]initWithTitle:@"correct" message:@"correct" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:@"ok:-)", nil];
       [cor show];
       newpage *np=[[newpage alloc]init];
       [self presentModalViewController:np animated:YES];
    
   }
   else{
       UIAlertView *ale=[[UIAlertView alloc]initWithTitle:@"invalid" message:@"tryagain" delegate:nil cancelButtonTitle:@"cancel" otherButtonTitles:@"ok", nil];
       [ale show];
       }
    
}
@end
