#import<Foundation/Foundation.h>
@interface arithmetic : NSObject
{
int first,second;
}
-(void)add;
-(void)sub;
-(void)mul;
-(void)did;
@property int first,second;
@end