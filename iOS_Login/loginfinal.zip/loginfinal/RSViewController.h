//
//  RSViewController.h
//  loginfinal
//
//  Created by MSE on 21/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RSViewController : UIViewController
{

    UITextField *textone;
    UITextField *texttwo;


}
@property (strong, nonatomic) IBOutlet UITextField *textone;
@property (strong, nonatomic) IBOutlet UITextField *texttwo;

- (IBAction)whenC:(id)sender;

@end
