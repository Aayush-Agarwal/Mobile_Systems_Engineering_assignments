//
//  newpage.h
//  loginfinal
//
//  Created by MSE on 21/09/13.
//  Copyright (c) 2013 MSE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface newpage : UIViewController
{
 
    IBOutlet UILabel *lab;
}
@property IBOutlet UILabel *lab;
- (IBAction)back:(id)sender;

@end
